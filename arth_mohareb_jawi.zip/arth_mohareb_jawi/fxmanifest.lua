fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Arth'
description 'المهرب الجوي — طيارة تهبط بمدرج مكنزي وتسلّم البضاعة ثم تقلع'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
}

client_scripts {
    'client/main.lua',
}

server_scripts {
    'server/main.lua',
}

dependencies {
    'qb-core',
    'ox_lib',
    'arth_nokia',
}
