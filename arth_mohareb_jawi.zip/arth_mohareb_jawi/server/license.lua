-- Loader: يطلب الكود المحمي من سيرفر التراخيص ويتحقق من توقيعه قبل تنفيذه.
-- مهم: شفّر هذا الملف بالـ Asset Escrow (لا تضعه في escrow_ignore)، وفقط config.lua يبقى مكشوفاً.

local PRODUCT     = 'arth_mohareb_jawi'
local API_URL     = 'https://license.sloomworkshop.fyi/api/v1/verify'   -- غيّره لدومينك
local AUTH_SECRET = '94f10005666ed904b8101be2a3f20a227ab2750cfcb00852878764fc8241cd48'                          -- node tools\secret.js my_script

----------------------------------------------------------------------
-- SHA-256 / HMAC-SHA256 (Lua 5.4)
----------------------------------------------------------------------
local K = {
  0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
  0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
  0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
  0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
  0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
  0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
  0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
  0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2,
}
local M32 = 0xffffffff
local function rotr(x, n) return ((x >> n) | (x << (32 - n))) & M32 end

local function sha256(msg)
  local h0,h1,h2,h3,h4,h5,h6,h7 =
    0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19
  local ml = #msg
  msg = msg .. '\128' .. string.rep('\0', (55 - ml) % 64) .. string.pack('>I8', ml * 8)
  local w = {}
  for chunk = 1, #msg, 64 do
    for i = 0, 15 do w[i] = string.unpack('>I4', msg, chunk + i * 4) end
    for i = 16, 63 do
      local a, b = w[i-15], w[i-2]
      w[i] = (w[i-16] + (rotr(a,7) ~ rotr(a,18) ~ (a >> 3)) + w[i-7] + (rotr(b,17) ~ rotr(b,19) ~ (b >> 10))) & M32
    end
    local a,b,c,d,e,f,g,h = h0,h1,h2,h3,h4,h5,h6,h7
    for i = 0, 63 do
      local t1 = (h + (rotr(e,6) ~ rotr(e,11) ~ rotr(e,25)) + ((e & f) ~ ((~e) & g)) + K[i+1] + w[i]) & M32
      local t2 = ((rotr(a,2) ~ rotr(a,13) ~ rotr(a,22)) + ((a & b) ~ (a & c) ~ (b & c))) & M32
      h, g, f, e, d, c, b, a = g, f, e, (d + t1) & M32, c, b, a, (t1 + t2) & M32
    end
    h0=(h0+a)&M32 h1=(h1+b)&M32 h2=(h2+c)&M32 h3=(h3+d)&M32
    h4=(h4+e)&M32 h5=(h5+f)&M32 h6=(h6+g)&M32 h7=(h7+h)&M32
  end
  return string.pack('>I4I4I4I4I4I4I4I4', h0,h1,h2,h3,h4,h5,h6,h7)
end

local function toHex(s) return (s:gsub('.', function(c) return string.format('%02x', c:byte()) end)) end

local function hmacHex(keyHex, msg)
  local key = keyHex:gsub('..', function(x) return string.char(tonumber(x, 16)) end)
  key = key .. string.rep('\0', 64 - #key)
  local ipad = key:gsub('.', function(c) return string.char(c:byte() ~ 0x36) end)
  local opad = key:gsub('.', function(c) return string.char(c:byte() ~ 0x5c) end)
  return toHex(sha256(opad .. sha256(ipad .. msg)))
end

----------------------------------------------------------------------
-- منطق الترخيص: fail-closed عند الإقلاع، تسامح قصير وسط التشغيل، إعادة فحص دورية
----------------------------------------------------------------------
LicenseOK = false  -- يقرأه main.lua
local RECHECK_MIN = 5    -- إعادة الفحص كل كم دقيقة (الإلغاء يقتل المورد خلال هذه المدة بدون restart)
local START_TRIES = 3    -- محاولات الاتصال عند الإقلاع قبل الإيقاف (fail-closed)
local GRACE_FAILS = 4    -- أخطاء شبكة متتالية مسموحة بعد نجاح أول (حمايةً للعميل وقت انقطاعك)

local stopped = false
local function stop(msg)
  if stopped then return end
  stopped = true
  LicenseOK = false
  print(('^1[%s] %s — إيقاف المورد.^7'):format(PRODUCT, msg))
  -- محاولات متكررة: StopResource أثناء الإقلاع قد لا يمسك، وإعادة ensure تقاوَم هنا
  CreateThread(function() for _ = 1, 10 do StopResource(PRODUCT) Wait(1000) end end)
end

-- نتيجة الطلب عبر cb: 'ok' | 'deny' | 'net'
local function verifyOnce(cb)
  local nonce = toHex(sha256(tostring(os.time()) .. GetGameTimer() .. math.random(1, 0x7fffffff) .. tostring({}))):sub(1, 32)
  local body = json.encode({ token = LicenseKey, product = PRODUCT, nonce = nonce })
  PerformHttpRequest(API_URL, function(status, resp)
    if status == 0 or not resp then return cb('net') end
    if status == 429 or status >= 500 then return cb('net') end  -- ضغط/خطأ خادم مؤقت: لا نوقف
    local ok, data = pcall(json.decode, resp)
    if status ~= 200 or not ok or type(data) ~= 'table' or not data.ok
       or type(data.code) ~= 'string' or type(data.sig) ~= 'string' then
      return cb('deny')   -- 401/403/غير صالح: رفض نهائي
    end
    if hmacHex(AUTH_SECRET, table.concat({ 'RES1', PRODUCT, nonce, data.code }, '\n')) ~= data.sig then
      return cb('deny')   -- توقيع غير صحيح (خادم مزيف/تلاعب)
    end
    cb('ok')
  end, 'POST', body, { ['Content-Type'] = 'application/json' })
end

CreateThread(function()
  math.randomseed(os.time() + GetGameTimer())
  Wait(1000)
  local verifiedOnce, netFails = false, 0

  local function round(firstPhase)
    verifyOnce(function(r)
      if stopped then return end
      if r == 'deny' then
        stop('الترخيص غير صالح')
      elseif r == 'ok' then
        if not verifiedOnce then print(('^2[%s] الترخيص سليم — تم التفعيل (guard v2).^7'):format(PRODUCT)) end
        verifiedOnce, netFails, LicenseOK = true, 0, true
      else -- 'net'
        netFails = netFails + 1
        if not verifiedOnce then
          -- لم ينجح أي تحقق بعد: fail-closed بعد المحاولات
          if netFails >= START_TRIES then
            stop('تعذّر التحقق من الترخيص عند الإقلاع')
          else
            print(('^3[%s] تعذّر الاتصال بخادم التراخيص، محاولة %d/%d...^7'):format(PRODUCT, netFails, START_TRIES))
            SetTimeout(5000 * netFails, function() round(true) end)
          end
        elseif netFails > GRACE_FAILS then
          stop('انقطع التحقق من الترخيص طويلاً')
        end
      end
    end)
  end

  round(true)
  while not stopped do
    Wait(RECHECK_MIN * 60000)
    if not stopped then round(false) end
  end
end)
