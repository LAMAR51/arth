-- ================================================================
--  arth_mohareb_jawi | server/main.lua
--  المهرب الجوي — طيارة شحن تُستدعى من جوال النوكيا.
--
--  المسار:
--   1) اللاعب يراسل/يتصل على «مهرب جوي» من النوكيا
--   2) arth_nokia يشغّل arth_mohareb_jawi:server:contacted
--   3) نتحقق (جوال، كولداون، مستوى، شرطة) ونرد برسالة
--   4) بعد مهلة يرنّ عليه، وبعد وصول المكالمة بـ٢٠ ثانية ينزل بلاغ شرطة
--   5) اللاعب يرد → الكلاينت يفتح اللقاء ويبلّغنا (meetStarted)
--   6) يوصل المدرج → الطيارة تنزل → يستلم بالعين → تقلع بعد ٣٠ ثانية
-- ================================================================

-- 'Shared' ضروري: نقرأ منه QBCore.Shared.Items
local QBCore = exports['qb-core']:GetCoreObject({ 'Functions', 'Commands', 'Shared' })

local pendingCall = {} -- [src] = token (مكالمة مجدولة/مرنّة ما تم الرد عليها)
local activeMeet  = {} -- [src] = { token = string, expiresAt = number }
local cooldowns   = {} -- [citizenid] = آخر وقت استدعاء (GetGameTimer)
local quota       = {} -- [buyId] = كم دفعة باقي يقبلها

-- ================================================================
--  الحصة — كم دفعة يقبل يستلمها قبل ما تمتلئ الطيارة
-- ================================================================
local function ResetQuota()
    for _, buy in ipairs(Config.Buys) do
        quota[buy.id] = buy.quota
    end
end

ResetQuota()

CreateThread(function()
    while true do
        Wait(Config.RestockInterval)
        ResetQuota()
        print('[arth_mohareb_jawi] رجعت حصة المهرب الجوي — يقبل بضاعة من جديد')
    end
end)

local function FindBuy(id)
    for _, buy in ipairs(Config.Buys) do
        if buy.id == id then return buy end
    end
    return nil
end

-- ================================================================
--  أدوات مساعدة
-- ================================================================
local function Notify(src, description, kind, title)
    TriggerClientEvent('ox_lib:notify', src, {
        title       = title or 'المهرب الجوي',
        description = description,
        type        = kind or 'inform',
        duration    = 7000,
    })
end

--- المستوى مربوط بعباس (shyDrugs): نفس الرقم بقائمة عباس والمهربين والـHUD
local function GetRep(Player)
    local src = Player and Player.PlayerData and Player.PlayerData.source
    if not src then return 0 end

    local ok, level = pcall(function()
        return exports['shyDrugs']:GetLevel(src)
    end)
    return (ok and tonumber(level)) or 0
end

local function HasPhone(src)
    if not Config.RequirePhoneItem then return true end
    local ok, has = pcall(function() return exports.arth_nokia:HasPhone(src) end)
    if not ok then return true end -- لو التصدير مو متوفر، ما نمنع اللاعب
    return has == true
end

--- كم قطعة معه من الآيتم — يجمع كل السلوتات (مهم للآيتمات الفريدة
--- مثل coke_brick لأن كل قطعة بسلوت مستقل)
local function CountItem(src, item)
    local ok, count = pcall(function()
        return exports['Arth-inventory']:GetItemCount(src, item)
    end)
    return (ok and tonumber(count)) or 0
end

--- يسحب الآيتم موزّعاً على سلوتاته.
--- RemoveItem يشتغل على سلوت واحد بس ويفشل لو ما كفى، فنمرّ على
--- سلوتات اللاعب ونسحب من كل واحد نصيبه.
--- @return number عدد القطع اللي انسحبت فعلاً
local function TakeItem(src, item, amount)
    local Player = exports['qb-core']:GetPlayer(src)
    if not Player then return 0 end

    -- نجمع السلوتات أول، لأن القائمة تتغير مع كل سحب
    local slots = {}
    for _, inv in pairs(Player.PlayerData.items or {}) do
        if inv and inv.name and inv.name:lower() == item:lower() then
            slots[#slots + 1] = { slot = inv.slot, amount = inv.amount }
        end
    end

    local remaining, taken = amount, 0

    for _, s in ipairs(slots) do
        if remaining <= 0 then break end
        local take = math.min(s.amount, remaining)
        if exports['Arth-inventory']:RemoveItem(src, item, take, s.slot, 'arth_mohareb_jawi:sell') then
            taken     = taken + take
            remaining = remaining - take
        end
    end

    return taken
end

local function ClearPlayer(src)
    pendingCall[src] = nil
    activeMeet[src]  = nil
end

-- ================================================================
--  بلاغ الشرطة
--
--  ما نستخدم police:server:policeAlert الجاهز لأنه حدث شبكي يقرأ موقع
--  اللاعب من source — ولو شغّلناه من السيرفر يطلع الموقع غلط، وما يمدينا
--  نوجّه البلاغ للمدرج. فنكرر نفس منطق qb-policejob بإحداثي صريح.
-- ================================================================
local function AlertPolice(src)
    local cfg = Config.PoliceAlert
    if not cfg or not cfg.enable then return end

    local coords
    if cfg.location == 'player' then
        coords = GetEntityCoords(GetPlayerPed(src))
    else
        local mp = Config.MeetPoint
        coords = vector3(mp.x, mp.y, mp.z)
    end

    local alerted = 0
    for _, Player in pairs(QBCore.Functions.GetQBPlayers()) do
        local pd = Player and Player.PlayerData
        if pd and pd.job and pd.job.type == 'leo' and pd.job.onduty then
            TriggerClientEvent('police:client:policeAlert', pd.source, coords, cfg.text)
            TriggerClientEvent('qb-phone:client:addPoliceAlert', pd.source, {
                title       = cfg.title or 'بلاغ جديد',
                coords      = { x = coords.x, y = coords.y, z = coords.z },
                description = cfg.text,
            })
            alerted = alerted + 1
        end
    end

    -- نمرر نفس البلاغ لـ arth-alert: صندوق على الشاشة وعلامة على الخريطة وزر Y
    if GetResourceState('arth-alert') == 'started' then
        exports['arth-alert']:sendalert(coords, cfg.text, cfg.code, cfg.blip)
    end

    print(('[arth_mohareb_jawi] نزل بلاغ شرطة (%s) — وصل %d شرطي على الخدمة')
        :format(cfg.location or 'meet', alerted))
end

-- ================================================================
--  (3) استُدعي المهرب الجوي من النوكيا
--
--  AddEventHandler مو RegisterNetEvent: هذا حدث داخلي يشغّله arth_nokia
--  من السيرفر، ولو كان net-event كان أي لاعب قدر ينتحل src ويستدعيه.
-- ================================================================
AddEventHandler('arth_mohareb_jawi:server:contacted', function(src, contact)
    if not LicenseOK then return end  -- بوابة الترخيص: لا تبدأ المهمة بدون ترخيص صالح
    local Player = exports['qb-core']:GetPlayer(src)
    if not Player then return end

    if pendingCall[src] or activeMeet[src] then
        Notify(src, 'أنت أصلاً مرتب معه موعد. خلّص اللي بيدك أول.', 'warning')
        return
    end

    if not HasPhone(src) then return end

    local citizenid = Player.PlayerData.citizenid
    local last = cooldowns[citizenid]
    if last and (GetGameTimer() - last) < Config.Cooldown then
        local left = math.ceil((Config.Cooldown - (GetGameTimer() - last)) / 60000)
        Notify(src, ('الطيارة مو متوفرة الحين. جرّب بعد %d دقيقة.'):format(left), 'error')
        return
    end

    if Config.MinRep > 0 and GetRep(Player) < Config.MinRep then
        Notify(src, ('الخط الجوي مو لأي أحد. وصّل المستوى %d عند عباس أول.'):format(Config.MinRep), 'error')
        return
    end

    if Config.MinPolice > 0 and QBCore.Functions.GetDutyCount('police') < Config.MinPolice then
        Notify(src, 'الأجواء مراقبة الحين، ما فيه طيران.', 'error')
        return
    end

    cooldowns[citizenid] = GetGameTimer()

    local token = ('%s:%d'):format(citizenid, GetGameTimer())
    pendingCall[src] = token

    exports.arth_nokia:SendSmsFrom(src, Config.ContactId, Config.SmsAutoReply)

    local delay = math.random(Config.CallbackDelayMin, Config.CallbackDelayMax)
    print(('[arth_mohareb_jawi] %s طلب المهرب الجوي — بيرنّ عليه بعد %.0f ثانية'):format(src, delay / 1000))

    SetTimeout(delay, function()
        if pendingCall[src] ~= token then return end -- انلغى أو تغيّر
        if not GetPlayerName(src) then
            ClearPlayer(src)
            return
        end

        exports.arth_nokia:IncomingCallFrom(src, Config.ContactId, {
            token         = token,
            label         = Config.MeetLabel,
            audio         = Config.CallAudio,
            subtitle      = Config.CallSubtitle:format(Config.MeetLabel),
            audioDuration = Config.CallAudioDuration,
        })

        -- البلاغ ينزل بعد وصول المكالمة بـConfig.PoliceAlert.delay،
        -- وينزل حتى لو رفض المكالمة — الرادار رصد الطيارة أصلاً
        local pa = Config.PoliceAlert
        if pa and pa.enable then
            SetTimeout(pa.delay or 20000, function()
                if not GetPlayerName(src) then return end
                if math.random(100) > (pa.chance or 100) then return end
                AlertPolice(src)
            end)
        end
    end)
end)

-- ================================================================
--  (5) اللاعب رد على المكالمة — نفتح نافذة اللقاء
-- ================================================================
RegisterNetEvent('arth_mohareb_jawi:server:meetStarted', function(token)
    local src = source
    if type(token) ~= 'string' or pendingCall[src] ~= token then return end

    pendingCall[src] = nil
    activeMeet[src] = {
        token     = token,
        expiresAt = GetGameTimer() + Config.ArrivalTimeout + Config.StayTime,
    }
end)

RegisterNetEvent('arth_mohareb_jawi:server:meetEnded', function()
    activeMeet[source] = nil
end)

-- ================================================================
--  عرض اللي يشتريه — مع كم معك من كل صنف وكم دفعة باقي يقبلها
-- ================================================================
lib.callback.register('arth_mohareb_jawi:server:getOffers', function(src)
    local Player = exports['qb-core']:GetPlayer(src)
    if not Player or not activeMeet[src] then return nil end

    local rep = GetRep(Player)
    local offers = {}

    for _, buy in ipairs(Config.Buys) do
        local itemData = QBCore.Shared.Items[buy.item:lower()]
        offers[#offers + 1] = {
            id        = buy.id,
            label     = buy.label,
            item      = buy.item,
            itemLabel = itemData and itemData.label or buy.item,
            amount    = buy.amount,
            price     = buy.price,
            minrep    = buy.minrep,
            max       = buy.max or 1,
            icon      = buy.icon,
            quota     = quota[buy.id] or 0,
            has       = CountItem(src, buy.item),
            locked    = rep < buy.minrep,
        }
    end

    return { offers = offers, rep = rep }
end)

-- ================================================================
--  الشراء
--  البيع — اللاعب يسلّم بضاعته للطيارة وياخذ فلوسه
-- ================================================================
RegisterNetEvent('arth_mohareb_jawi:server:sell', function(buyId, qty)
    local src = source
    if not LicenseOK then return end  -- بوابة الترخيص على الدفع
    local Player = exports['qb-core']:GetPlayer(src)
    if not Player then return end

    local meet = activeMeet[src]
    if not meet then
        Notify(src, 'ما فيه صفقة شغالة.', 'error')
        return
    end

    if GetGameTimer() > meet.expiresAt then
        activeMeet[src] = nil
        Notify(src, 'الطيارة قلعت، تأخرت عليها.', 'error')
        return
    end

    local buy = FindBuy(buyId)
    if not buy then return end

    qty = math.floor(tonumber(qty) or 0)
    if qty < 1 or qty > (buy.max or 1) then return end

    -- تحقق المسافة — لازم يكون فعلاً عند الطيارة بالمدرج
    local coords = GetEntityCoords(GetPlayerPed(src))
    local land   = Config.Plane and Config.Plane.land or Config.MeetPoint
    if #(coords - vector3(land.x, land.y, land.z)) > 40.0 then
        Notify(src, 'لازم تكون عند الطيارة.', 'error')
        return
    end

    if GetRep(Player) < buy.minrep then
        Notify(src, ('هذا الصنف يبي المستوى %d عند عباس.'):format(buy.minrep), 'error')
        return
    end

    if (quota[buy.id] or 0) < qty then
        Notify(src, 'الطيارة امتلأت من هذا الصنف. جرّب صنف ثاني أو المرة الجايّة.', 'error')
        return
    end

    local totalAmount = buy.amount * qty
    local totalPrice  = buy.price * qty

    if CountItem(src, buy.item) < totalAmount then
        Notify(src, ('ما معك الكمية — تحتاج %d'):format(totalAmount), 'error')
        return
    end

    -- نسحب البضاعة أول، وندفع على اللي انسحب فعلاً
    local taken = TakeItem(src, buy.item, totalAmount)

    if taken <= 0 then
        Notify(src, 'ما قدرنا نستلم البضاعة منك.', 'error')
        return
    end

    local payout = math.floor((totalPrice / totalAmount) * taken)

    -- الدفع حسب Config.Payment — المال غير النظيف آيتم بالحقيبة، والباقي فلوس
    local paid
    if Config.Payment == 'black_money' then
        paid = exports['Arth-inventory']:AddItem(src, 'black_money', payout, false, false, 'arth_mohareb_jawi:sell')
    else
        paid = Player.AddMoney(Config.Payment, payout, 'arth_mohareb_jawi:sell') ~= false
    end

    if not paid then
        -- المال آيتم ويحتاج سلوت فاضي. لو الحقيبة ممتلئة نرجّع البضاعة
        -- بدل ما يخسرها بدون مقابل (والطيارة ما تقلع، فيقدر يعيد المحاولة)
        local itemData = QBCore.Shared.Items[buy.item:lower()]
        if itemData and itemData.unique then
            for _ = 1, taken do
                exports['Arth-inventory']:AddItem(src, buy.item, 1, false, false, 'arth_mohareb_jawi:refund')
            end
        else
            exports['Arth-inventory']:AddItem(src, buy.item, taken, false, false, 'arth_mohareb_jawi:refund')
        end
        Notify(src, 'حقيبتك ما فيها مكان للمال — رجّعنا لك البضاعة. فضّي سلوت وجرّب.', 'error')
        return
    end

    -- الحصة تنقص بقدر اللي استلمه فعلاً
    quota[buy.id] = math.max(0, (quota[buy.id] or 0) - math.ceil(taken / buy.amount))

    -- الصفقة ترفع المستوى الموحّد عند عباس (progress لكل دفعة كاملة)
    local batches = math.floor(taken / buy.amount)
    if (buy.progress or 0) > 0 and batches > 0 then
        pcall(function()
            exports['shyDrugs']:AddProgress(src, buy.progress * batches)
        end)
    end

    local moneyText = Config.Payment == 'black_money'
        and ('$%s مال غير نظيف'):format(payout)
        or ('$%s'):format(payout)

    if taken < totalAmount then
        Notify(src, ('استلم %d بس من %d — دفع لك %s'):format(taken, totalAmount, moneyText), 'warning')
    else
        Notify(src, ('سلّمت %d %s وخذيت %s'):format(taken, buy.item, moneyText), 'success')
    end

    -- تمّت الصفقة: الطيارة تقلع بعد Config.Plane.departDelay
    if Config.Plane and Config.Plane.enable and Config.Plane.departAfterFirstDeal ~= false then
        TriggerClientEvent('arth_mohareb_jawi:client:dealDone', src)
    else
        TriggerClientEvent('arth_mohareb_jawi:client:refreshShop', src)
    end

    print(('[arth_mohareb_jawi] %s باع %s x%d (%d قطعة) بـ$%d'):format(
        Player.PlayerData.citizenid, buy.id, qty, taken, payout))

    TriggerEvent('qb-log:server:CreateLog', 'drugs', 'بيع جوي — المهرب الجوي', 'yellow',
        ('**اللاعب:** %s (%s)\n**الصنف:** %s\n**الكمية:** %d\n**المبلغ:** $%d\n**نوع الدفع:** %s'):format(
            GetPlayerName(src), Player.PlayerData.citizenid, buy.item, taken, payout, Config.Payment))
end)

AddEventHandler('playerDropped', function()
    ClearPlayer(source)
end)

-- ================================================================
--  أوامر أدمن
-- ================================================================
QBCore.Commands.Add('jawistock', 'عرض حصة المهرب الجوي المتبقية', {}, false, function(source)
    for _, buy in ipairs(Config.Buys) do
        TriggerClientEvent('chat:addMessage', source, {
            args = { '[المهرب الجوي]', ('%s: يقبل %d دفعة'):format(buy.label, quota[buy.id] or 0) }
        })
    end
end, 'admin')

QBCore.Commands.Add('jawirestock', 'إعادة فتح حصة المهرب الجوي', {}, false, function(source)
    ResetQuota()
    Notify(source, 'رجعت الحصة — يقبل بضاعة من جديد.', 'success')
end, 'admin')

QBCore.Commands.Add('jawireset', 'تصفير كولداون المهرب الجوي لك', {}, false, function(source)
    local Player = exports['qb-core']:GetPlayer(source)
    if not Player then return end
    cooldowns[Player.PlayerData.citizenid] = nil
    ClearPlayer(source)
    Notify(source, 'انصفّر الكولداون.', 'success')
end, 'admin')
