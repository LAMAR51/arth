-- ================================================================
--  arth_mohareb_jawi | client/main.lua
--  يستلم المكالمة من جوال النوكيا، يرسم الطريق للمدرج، ينزّل الطيارة
--  من الجو، وتصير العين على الطيارة نفسها. بعد التسليم بـ٣٠ ثانية تقلع.
-- ================================================================

local meetActive   = false
local meetBlip     = nil
local planeEntity  = nil
local pilotPed     = nil
local planeBlip    = nil
local guardPeds    = {}
local targeted     = {} -- كل كيان انربط بالعين، عشان نفكّه وقت الحذف
local arrived      = false
local planeLanded  = false
local departing    = false
local crewSpawned  = false -- الطاقم ينزل مرة وحدة بكل لقاء، ما يتكرر
local meetGen      = 0     -- رقم اللقاء: أي مؤقت من لقاء قديم يتجاهل نفسه

local OpenShop -- تعريف مسبق: BindTarget تستدعيها قبل ما تتكتب
local EndMeet  -- تعريف مسبق: DepartPlane تستدعيها بعد التنظيف

-- ================================================================
--  أدوات
-- ================================================================
local function LoadModel(model)
    local hash = type(model) == 'number' and model or joaat(model)
    if not IsModelInCdimage(hash) or not IsModelValid(hash) then
        print(('[arth_mohareb_jawi] موديل غير صالح: %s'):format(tostring(model)))
        return nil
    end

    RequestModel(hash)
    local timeout = GetGameTimer() + 10000
    while not HasModelLoaded(hash) and GetGameTimer() < timeout do Wait(10) end
    if not HasModelLoaded(hash) then return nil end

    return hash
end

--- freeze = false للبوتات اللي راكبة مركبة (التجميد يخربط قعدتهم)
local function SetupStaticPed(ped, scenario, freeze)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetPedDiesWhenInjured(ped, false)
    SetPedCanRagdollFromPlayerImpact(ped, false)
    SetPedFleeAttributes(ped, 0, false)
    if freeze ~= false then FreezeEntityPosition(ped, true) end
    if scenario then TaskStartScenarioInPlace(ped, scenario, 0, true) end
end

--- يربط كيان بالعين ويسجّله عشان ينفك وقت الحذف
local function BindTarget(entity, label, icon, distance)
    exports['Arth-target']:AddTargetEntity(entity, {
        options = {
            {
                icon   = icon or 'fas fa-parachute-box',
                label  = label or 'استلم الشحنة',
                action = function() OpenShop() end,
            },
        },
        distance = distance or 4.0,
    })
    targeted[#targeted + 1] = entity
end

local function GroundZAt(x, y, z)
    if Config.GuardGroundZ ~= false then
        local found, groundZ = GetGroundZFor_3dCoord(x, y, z + 2.0, false)
        if found then return groundZ end
    end
    return z + (Config.GuardZOffset or -1.0)
end

local function MeetAnchor()
    local mp = Config.MeetPoint
    return vector3(mp.x, mp.y, mp.z)
end

--- يلف إزاحة محلية (يمين/قدّام) حسب اتجاه معيّن.
--- باتجاه GTA: قدّام = (-sin, cos) و يمين = (cos, sin).
local function RotateOffset(off, heading)
    local rad = math.rad(heading)
    local s, c = math.sin(rad), math.cos(rad)
    return vector3(
        off.x * c + off.y * -s,
        off.x * s + off.y * c,
        off.z or 0.0
    )
end

-- ================================================================
--  متجر الجملة
-- ================================================================
--- نص المبلغ حسب نوع الدفع (مال غير نظيف أو كاش/بنك)
local function MoneyText(amount)
    if Config.Payment == 'black_money' then
        return ('$%s مال غير نظيف'):format(amount)
    end
    return ('$%s'):format(amount)
end

--- أقصى دفعات يقدر يبيعها: محدودة بحد الصفقة، وبحصة الطيارة،
--- وبالكمية اللي معه فعلاً
local function MaxLots(offer)
    return math.min(
        offer.max or 1,
        offer.quota or 0,
        math.floor((offer.has or 0) / offer.amount)
    )
end

local function SellLot(offer)
    local limit = MaxLots(offer)
    if limit < 1 then return end

    local qty = 1

    if limit > 1 then
        local input = lib.inputDialog(offer.label, {
            {
                type     = 'number',
                label    = ('كم دفعة تسلّم؟ (أقصى %d)'):format(limit),
                min      = 1,
                max      = limit,
                default  = 1,
                required = true,
            },
        })
        if not input or not input[1] then return end
        qty = math.floor(input[1])
        if qty < 1 or qty > limit then return end
    end

    local total  = offer.price * qty
    local pieces = offer.amount * qty

    local confirm = lib.alertDialog({
        header   = 'تأكيد التسليم',
        content  = ('**%s**\n\nتسلّم: %d %s\nتاخذ: %s\n\nتمشي الصفقة؟')
            :format(offer.label, pieces, offer.itemLabel, MoneyText(total)),
        centered = true,
        cancel   = true,
        labels   = { confirm = 'أكيد', cancel = 'لا' },
    })
    if confirm ~= 'confirm' then return end

    local done = lib.progressBar({
        duration  = 5000,
        label     = 'تحمّل الشحنة بالطيارة...',
        canCancel = true,
        disable   = { move = true, car = true, combat = true },
        anim      = { dict = 'anim@heists@box_carry@', clip = 'idle', flag = 49 },
    })
    if not done then return end

    TriggerServerEvent('arth_mohareb_jawi:server:sell', offer.id, qty)
end

OpenShop = function()
    local data = lib.callback.await('arth_mohareb_jawi:server:getOffers', false)
    if not data or not data.offers then
        lib.notify({ title = 'المهرب الجوي', description = 'ما فيه صفقة شغالة الحين.', type = 'error' })
        return
    end

    local options = {}

    for _, offer in ipairs(data.offers) do
        local description
        local disabled = false

        if offer.locked then
            description = ('مقفول — يبي المستوى %d (مستواك %d)'):format(offer.minrep, data.rep)
            disabled = true
        elseif offer.quota < 1 then
            description = 'الطيارة امتلأت من هذا الصنف'
            disabled = true
        elseif offer.has < offer.amount then
            description = ('الدفعة %d × %s — معك %d بس')
                :format(offer.amount, offer.itemLabel, offer.has)
            disabled = true
        else
            description = ('%d × %s ← %s للدفعة | معك %d | يقبل %d دفعة')
                :format(offer.amount, offer.itemLabel, MoneyText(offer.price), offer.has, offer.quota)
        end

        options[#options + 1] = {
            title       = offer.label,
            description = description,
            icon        = offer.icon,
            disabled    = disabled,
            onSelect    = function() SellLot(offer) end,
        }
    end

    lib.registerContext({
        id      = 'arth_jawi_shop',
        title   = ('المهرب الجوي — يشتري منك (مستواك %d)'):format(data.rep),
        options = options,
    })
    lib.showContext('arth_jawi_shop')
end

RegisterNetEvent('arth_mohareb_jawi:client:refreshShop', function()
    if departing then return end
    if meetActive and planeEntity and DoesEntityExist(planeEntity) then
        OpenShop()
    end
end)

-- ================================================================
--  الطيارة: تهبط من الجو، تنتظرك، وتقلع بعد التسليم
-- ================================================================

--- تحرّك الطيارة بخط مستقيم للهدف مع ميلان أنف يطابق زاوية الصعود/الهبوط.
--- مبرمجة بالكامل: ما تعتمد على TaskPlaneLand اللي يفشل كثير، وما تعلق
--- بتضاريس ولا تحتاج مدرج معترف فيه باللعبة.
local function ScriptedFly(target, speed, stopRange, onArrive)
    CreateThread(function()
        if not (planeEntity and DoesEntityExist(planeEntity)) then return end
        FreezeEntityPosition(planeEntity, true)

        local lastTick = GetGameTimer()

        while meetActive and planeEntity and DoesEntityExist(planeEntity) do
            Wait(0)

            local now = GetGameTimer()
            local dt  = (now - lastTick) / 1000.0
            lastTick  = now

            local pos  = GetEntityCoords(planeEntity)
            local dx, dy, dz = target.x - pos.x, target.y - pos.y, target.z - pos.z
            local flat = math.sqrt(dx * dx + dy * dy)
            local dist = math.sqrt(flat * flat + dz * dz)

            if dist <= stopRange then
                if onArrive then onArrive() end
                return
            end

            local step = math.min(speed * dt, dist)
            local nx = pos.x + (dx / dist) * step
            local ny = pos.y + (dy / dist) * step
            local nz = pos.z + (dz / dist) * step

            SetEntityCoordsNoOffset(planeEntity, nx, ny, nz, false, false, false)

            -- ميلان الأنف يطابق زاوية المسار، عشان تبين طايرة فعلاً.
            -- لو المسار شبه عمودي، flat يقارب الصفر فنحافظ على الاتجاه
            -- الحالي بدل ما تطلع قسمة على صفر.
            if flat > 0.5 then
                local pitch   = math.deg(math.atan(dz, flat))
                local heading = GetHeadingFromVector_2d(dx / flat, dy / flat)
                SetEntityRotation(planeEntity, pitch, 0.0, heading, 2, true)
            end
        end
    end)
end

--- تنزّل الطيارة على المدرج: تسوّيها، تحط عجلاتها على الأرض، وتثبّتها
local function LandPlane()
    if planeLanded or not planeEntity or not DoesEntityExist(planeEntity) then return end
    planeLanded = true

    local cfg  = Config.Plane
    local land = cfg.land

    -- سواقة الطيران مو دقيقة — نضبطها على نقطة الهبوط بالضبط
    SetEntityCoordsNoOffset(planeEntity, land.x, land.y, land.z + 2.0, false, false, false)
    SetEntityRotation(planeEntity, 0.0, 0.0, land.w + 0.0, 2, true)
    SetEntityHeading(planeEntity, land.w + 0.0)

    -- تحط العجلات على الأرض بالضبط بدل ما نخمّن ارتفاع بدن الطيارة
    FreezeEntityPosition(planeEntity, false)
    SetVehicleOnGroundProperly(planeEntity)
    SetVehicleForwardSpeed(planeEntity, 0.0)
    FreezeEntityPosition(planeEntity, true)

    if planeBlip and DoesBlipExist(planeBlip) then RemoveBlip(planeBlip) end
    planeBlip = nil

    -- العين على الطيارة نفسها
    BindTarget(planeEntity, cfg.targetLabel, cfg.targetIcon, cfg.targetDistance)

    lib.notify({
        title       = 'المهرب الجوي',
        description = 'الطيارة نزلت. روح لها وسلّم بضاعتك بالعين.',
        type        = 'success',
        duration    = 9000,
    })
end

--- تراقب وصول الطيارة لنقطة الهبوط
local function WatchPlaneApproach()
    CreateThread(function()
        local cfg     = Config.Plane
        local land    = vector3(cfg.land.x, cfg.land.y, cfg.land.z)
        local elapsed = 0

        while meetActive and not planeLanded and planeEntity and DoesEntityExist(planeEntity) do
            Wait(250)
            elapsed = elapsed + 250

            if #(GetEntityCoords(planeEntity) - land) <= (cfg.landRange or 12.0) then
                LandPlane()
                return
            end

            if elapsed >= (cfg.approachTimeout or 60000) then
                print('[arth_mohareb_jawi] الطيارة ما وصلت بالوقت — نزّلتها بنقطة الهبوط مباشرة')
                LandPlane()
                return
            end
        end
    end)
end

local function SpawnPlane()
    local cfg = Config.Plane
    if not cfg or not cfg.enable then return end
    if planeEntity and DoesEntityExist(planeEntity) then return end

    local hash = LoadModel(cfg.model)
    if not hash then return end

    local fly = cfg.flyIn ~= false and cfg.spawn ~= nil
    local sx, sy, sz, sh

    if fly then
        sx, sy, sz = cfg.spawn.x, cfg.spawn.y, cfg.spawn.z
        sh = GetHeadingFromVector_2d(cfg.land.x - sx, cfg.land.y - sy)
    else
        sx, sy, sz, sh = cfg.land.x, cfg.land.y, cfg.land.z + 2.0, cfg.land.w + 0.0
    end

    planeEntity = CreateVehicle(hash, sx, sy, sz, sh, false, false)
    SetModelAsNoLongerNeeded(hash)
    if not DoesEntityExist(planeEntity) then
        planeEntity = nil
        return
    end

    SetEntityAsMissionEntity(planeEntity, true, true)
    SetEntityInvincible(planeEntity, true)
    SetVehicleDoorsLocked(planeEntity, 2) -- ما تنسرق
    SetVehicleHasBeenOwnedByPlayer(planeEntity, false)
    SetVehicleEngineOn(planeEntity, true, true, false)

    if fly then
        SetVehicleLandingGear(planeEntity, 0) -- العجلات نازلة للهبوط
    end

    -- الطيار
    if cfg.ped and cfg.ped.model then
        local pHash = LoadModel(cfg.ped.model)
        if pHash then
            pilotPed = CreatePedInsideVehicle(planeEntity, 4, pHash, cfg.ped.seat or -1, false, false)
            SetModelAsNoLongerNeeded(pHash)
            if DoesEntityExist(pilotPed) then
                SetupStaticPed(pilotPed, nil, false)
                SetPedCanBeDraggedOut(pilotPed, false)
            else
                pilotPed = nil
            end
        end
    end

    if not fly then
        LandPlane()
        return
    end

    ScriptedFly(
        vector3(cfg.land.x, cfg.land.y, cfg.land.z + 2.0),
        cfg.approachSpeed or 55.0,
        cfg.landRange or 12.0,
        LandPlane
    )

    if cfg.blip then
        planeBlip = AddBlipForEntity(planeEntity)
        SetBlipSprite(planeBlip, 16)
        SetBlipColour(planeBlip, 5)
        SetBlipScale(planeBlip, 0.9)
        SetBlipAsShortRange(planeBlip, false)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentString(exports['arth_bliptext']:fmt('✈️ طيارة المهرب'))
        EndTextCommandSetBlipName(planeBlip)
    end

    lib.notify({
        title       = 'المهرب الجوي',
        description = 'الطيارة بالجو وجايّة تنزل — جهّز البضاعة وخلك بالمدرج.',
        type        = 'inform',
        duration    = 9000,
    })

    WatchPlaneApproach()
end

--- يحذف الحراس الأرضيين — ينادى وقت الإقلاع
local function DespawnGroundCrew()
    for _, guard in ipairs(guardPeds) do
        if DoesEntityExist(guard) then DeleteEntity(guard) end
    end
    guardPeds = {}
end

--- بعد التسليم: تنبّهك، تقلع من أمامك، وتنحذف أول ما تبتعد
local function DepartPlane()
    if departing then return end
    departing = true

    local cfg   = Config.Plane
    local delay = cfg.departDelay or 30000
    local gen   = meetGen -- نتجاهل نفسنا لو اللقاء انتهى وبدأ غيره

    lib.notify({
        title       = 'المهرب الجوي',
        description = ('ابعد عن المدرج — الطيارة بتقلع بعد %d ثانية.'):format(math.floor(delay / 1000)),
        type        = 'warning',
        duration    = delay,
    })

    SetTimeout(delay, function()
        if gen ~= meetGen then return end

        if not planeEntity or not DoesEntityExist(planeEntity) then
            EndMeet(nil)
            return
        end

        -- نفك العين عنها عشان ما تبقى قابلة للتفاعل وهي طايرة
        exports['Arth-target']:RemoveTargetEntity(planeEntity)
        DespawnGroundCrew()

        SetVehicleLandingGear(planeEntity, 1) -- ترفع العجلات

        local to = cfg.departTo or vector3(cfg.land.x, cfg.land.y, cfg.land.z + 200.0)
        ScriptedFly(to, cfg.departSpeed or 60.0, 25.0, nil)

        lib.notify({
            title       = 'المهرب الجوي',
            description = 'قلعت. لين المرة الجايّة.',
            type        = 'inform',
            duration    = 8000,
        })

        -- التنظيف: أول ما تبتعد عن نظرك تنحذف، وبمهلة قصوى كشبكة أمان
        CreateThread(function()
            local waited = 0
            local cap    = cfg.departCleanup or 40000
            local far    = cfg.despawnDistance or 400.0

            while gen == meetGen and waited < cap do
                Wait(500)
                waited = waited + 500

                if not (planeEntity and DoesEntityExist(planeEntity)) then break end
                if #(GetEntityCoords(PlayerPedId()) - GetEntityCoords(planeEntity)) >= far then break end
            end

            if gen == meetGen then EndMeet(nil) end
        end)
    end)
end

-- السيرفر يبلّغنا بعد كل صفقة ناجحة
RegisterNetEvent('arth_mohareb_jawi:client:dealDone', function()
    if not meetActive then return end
    DepartPlane()
end)

-- ================================================================
--  الحراس والطاقم
-- ================================================================
local function SpawnGuards()
    if not (Config.Guards and Config.Guards.enable) then return end

    local mp       = MeetAnchor()
    local baseHead = Config.MeetPoint.w + 0.0

    for _, spot in ipairs(Config.Guards.spots or {}) do
        local model = Config.Guards.models[math.random(1, #Config.Guards.models)]
        local gHash = LoadModel(model)
        if gHash then
            local rot = RotateOffset(spot.offset, baseHead)
            local gx, gy = mp.x + rot.x, mp.y + rot.y
            local gz = GroundZAt(gx, gy, mp.z) + (spot.offset.z or 0.0)
            local guard = CreatePed(4, gHash, gx, gy, gz, baseHead + (spot.heading or 0.0), false, false)
            SetModelAsNoLongerNeeded(gHash)
            if DoesEntityExist(guard) then
                SetupStaticPed(guard, 'WORLD_HUMAN_GUARD_STAND')
                if Config.Guards.weapon then
                    GiveWeaponToPed(guard, joaat(Config.Guards.weapon), 200, false, true)
                end
                guardPeds[#guardPeds + 1] = guard
            end
        end
    end
end

local function SpawnCrew()
    -- الطاقم ينزل **مرة وحدة** بكل لقاء. الفحص على وجود الكيانات وحده ما
    -- يكفي: الطيارة كيان محلي والمحرك يقدر يحذفها لما تبعد، فترجع تنزل
    -- من نفسها بدون طلب.
    if crewSpawned or departing or not meetActive then return false end
    crewSpawned = true

    SpawnGuards()

    if Config.Plane and Config.Plane.enable then
        SpawnPlane()
    end

    return true
end

local function DespawnCrew()
    for _, entity in ipairs(targeted) do
        if DoesEntityExist(entity) then
            exports['Arth-target']:RemoveTargetEntity(entity)
        end
    end
    targeted = {}

    if planeBlip and DoesBlipExist(planeBlip) then RemoveBlip(planeBlip) end
    planeBlip = nil

    DespawnGroundCrew()

    -- الطيار قبل الطيارة، عشان ما يطيح بالأرض وقت ما تنحذف
    if pilotPed and DoesEntityExist(pilotPed) then DeleteEntity(pilotPed) end
    pilotPed = nil

    if planeEntity and DoesEntityExist(planeEntity) then
        SetEntityAsMissionEntity(planeEntity, true, true)
        DeleteVehicle(planeEntity)
        if DoesEntityExist(planeEntity) then DeleteEntity(planeEntity) end
    end
    planeEntity = nil

    planeLanded = false
    departing   = false
    crewSpawned = false
end

-- ================================================================
--  البلب
-- ================================================================
local function CreateMeetBlip()
    if not Config.Blip or not Config.Blip.enable then return end

    local mp = MeetAnchor()
    meetBlip = AddBlipForCoord(mp.x, mp.y, mp.z)
    SetBlipSprite(meetBlip, Config.Blip.sprite or 1)
    SetBlipColour(meetBlip, Config.Blip.color or 5)
    SetBlipScale(meetBlip, Config.Blip.scale or 1.0)
    SetBlipAsShortRange(meetBlip, false)
    if Config.Blip.route then
        SetBlipRoute(meetBlip, true)
        SetBlipRouteColour(meetBlip, Config.Blip.color or 5)
    end
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(exports['arth_bliptext']:fmt(Config.Blip.label or 'لقاء المهرب الجوي'))
    EndTextCommandSetBlipName(meetBlip)
end

local function ClearMeetBlip()
    if meetBlip and DoesBlipExist(meetBlip) then RemoveBlip(meetBlip) end
    meetBlip = nil
end

-- ================================================================
--  إنهاء اللقاء
-- ================================================================
EndMeet = function(reason)
    if not meetActive then return end

    meetActive = false
    arrived    = false
    meetGen    = meetGen + 1 -- يبطّل أي مؤقت أو ثريد من هذا اللقاء

    ClearMeetBlip()
    DespawnCrew()
    TriggerServerEvent('arth_mohareb_jawi:server:meetEnded')

    if reason then
        lib.notify({ title = 'المهرب الجوي', description = reason, type = 'error', duration = 8000 })
    end
end

-- ================================================================
--  مراقبة الوصول
-- ================================================================
local function WatchMeet()
    CreateThread(function()
        local target   = MeetAnchor()
        local elapsed  = 0
        local stayLeft = Config.StayTime

        while meetActive do
            Wait(1000)

            local dist = #(GetEntityCoords(PlayerPedId()) - target)

            if not arrived then
                elapsed = elapsed + 1000

                if dist <= Config.SpawnRadius then
                    SpawnCrew()
                end

                if dist <= 40.0 then
                    arrived = true
                    ClearMeetBlip()
                    lib.notify({
                        title       = 'المهرب الجوي',
                        description = 'وصلت المدرج. انتظر الطيارة تنزل وجهّز شحنتك.',
                        type        = 'success',
                        duration    = 8000,
                    })
                elseif elapsed >= Config.ArrivalTimeout then
                    EndMeet('تأخرت، الطيارة ما نزلت.')
                    return
                end
            elseif not departing then
                -- وقت الإقلاع، DepartPlane هي اللي تتحكم بالنهاية
                if dist > Config.SpawnRadius + 80.0 then
                    EndMeet('ابتعدت عن المدرج، الطيارة راحت.')
                    return
                end

                stayLeft = stayLeft - 1000
                if stayLeft <= 0 then
                    EndMeet('خلص وقتها وقلعت.')
                    return
                end
            end
        end
    end)
end

-- ================================================================
--  المكالمة من جوال النوكيا
-- ================================================================
AddEventHandler('arth_nokia:client:callAnswered', function(call)
    if not call or call.contactId ~= Config.ContactId then return end
    if meetActive then return end

    meetActive  = true
    arrived     = false
    departing   = false
    planeLanded = false
    crewSpawned = false
    meetGen     = meetGen + 1

    TriggerServerEvent('arth_mohareb_jawi:server:meetStarted', call.token)

    CreateMeetBlip()

    lib.notify({
        title       = 'المهرب الجوي',
        description = ('المدرج تحدد على خريطتك — %s. عندك %d دقيقة توصل.')
            :format(Config.MeetLabel, math.floor(Config.ArrivalTimeout / 60000)),
        type        = 'inform',
        duration    = 10000,
    })

    WatchMeet()
end)

AddEventHandler('arth_nokia:client:callDeclined', function(call)
    if not call or call.contactId ~= Config.ContactId then return end
    EndMeet(nil)
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    ClearMeetBlip()
    DespawnCrew()
end)
